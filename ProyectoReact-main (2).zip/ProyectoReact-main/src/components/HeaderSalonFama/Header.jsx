import React from "react";

function HeaderSalon(){
    return(
        <div className="headersalon">
        <h1>
            Salón de la Fama del Boxeo Mexicano
        </h1>
        </div>
    )
}

export default HeaderSalon