import React from "react";
import Card from "../components/Cards";
import HeaderSalon from "../components/HeaderSalonFama/Header";
import './SalonFama.css';


function SalonFama() {
  const cardsData = [
    {
      image: '/img/pipinoc.jpg',
      title: 'José "Pipino" Cuevas, record de (35-15) es un excampeón mundial de boxeo en la división de peso wélter. Poseedor de un poder de puños impresionante, ganando muchos de sus combates antes del límite.',
      link: 'https://es.wikipedia.org/wiki/Pipino_Cuevas'
      
    },
    {
      image: '/img/Finito.jpg',
      title: 'Ricardo "El Finito" López (51-0-1) Fue campeón mundial de peso mínimo del Consejo Mundial de Boxeo, también ganó los campeonatos de la Asociación Mundial de Boxeo y la Organización Mundial de Boxeo en la misma categoría. ',
      link: 'https://es.wikipedia.org/wiki/Ricardo_L%C3%B3pez_(boxeador)'
    },
    {
      image: '/img/Julio.jpg',
      title: 'Julio César Chávez (107-6-2) es un ex boxeador profesional mexicano que compitió profesionalmente entre 1980 y 2005, obteniendo títulos mundiales en tres diferentes divisiones de peso: superpluma, ligero, y superligero.',
      link: 'https://es.wikipedia.org/wiki/Julio_C%C3%A9sar_Ch%C3%A1vez'
    },
    {
      image: '/img/Dinamita.jpeg',
      title: 'Juan Manuel "Dinamita" Márquez (56-7-1) Es el cuarto boxeador mexicano en convertirse en campeón del mundo en tres categorías de peso después de Julio César Chávez, Erik Morales y Marco Antonio Barrera. ',
      link: 'https://es.wikipedia.org/wiki/Juan_Manuel_M%C3%A1rquez_(boxeador)'
    },
    {
      image: '/img/barrera.jpg',
      title: '- Marco Antonio Barrera (68-7) Fue campeón mundial en tres divisiones diferentes: Supergallo por la OMB; Pluma por el CMB; y Superpluma por el CMB y la FIB.',
      link: 'https://es.wikipedia.org/wiki/Marco_Antonio_Barrera'
    }

  ];

  return (
    <div className="app">
      <HeaderSalon /> {/* Agregar HeaderSalon */}
      <div className="card-container">
        {cardsData.map((card, index) => (
          <Card 
            key={index}
            image={card.image}
            title={card.title}
            link={card.link}
          />
        ))}
      </div>
    </div>
  );
}

export default SalonFama;